#ifndef DATE_H
#define DATE_H

class Date {
	private:
		int yyyy;
		int mm;
		int dd;
	public:
		Date();
		void set();
		void display();
};

#endif 
