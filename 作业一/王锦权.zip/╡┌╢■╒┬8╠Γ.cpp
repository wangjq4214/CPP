// �ڶ���8��

#include <iostream>

using namespace std;

int main()
{
	char ch[6] = "China";
	
	for (int i = 0; i < 5; i++)
	{
		ch[i] += 4;
		cout << ch[i];
	}
	return 0;
} 
