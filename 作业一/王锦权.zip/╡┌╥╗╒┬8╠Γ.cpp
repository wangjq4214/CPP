//��һ��8��

#include <iostream>

using namespace std;

int main()
{
	int a, b, c;
	cin >> a >> b;
	c = a + b;
	cout << "a + b = " << c;
} 
